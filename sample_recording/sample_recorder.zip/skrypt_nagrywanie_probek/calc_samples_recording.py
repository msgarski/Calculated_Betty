#!/usr/bin python3.6

#from calcfunctions import *
import numpy as np
from statistics import mean
import pyaudio
import time
import wave
import math
import os

# Ogólne dane pliku audio:
chunk = 1024  # Record in chunks of 1024 samples
sample_format = pyaudio.paInt16  # 16 bits per sample
channels = 1
fs = 44100  # Record at 44100 samples per second
seconds = 3


# Gotowa:
def truncate_from(ys, n):
    """Trims a wave array to the given length.
    ys: wave array
    n: integer length
    returns: wave array
    """
    return ys[n:]
# Gotowa:
def truncate_to(ys, n):
    """Trims a wave array to the given length.
    ys: wave array
    n: integer length
    returns: wave array
    """
    return ys[:n]

def truncate_from_to(ys, start, end):
    """Trims a wave array to the given length.
    ys: wave array
    n: integer length
    returns: wave array
    """
    return ys[start:end]

# Gotowa;
def word_from_to(ys, noise_level = 0, block = 128):     # niegotowa
    """
    Function for recognizing where vioce is started
    :param ys: numpy array
    :param threshold:   noise level
    :param block:   size of block
    :return:    frame from which is voice, till which should be cutted
    """
    max_block = int(len(ys) / block)
    num_block = 0
    frame = []
    vals = []
    j = 0
    start_point = 0
    end_point = 0
    while num_block < max_block:
        for i in range(0, block):
            frame.append(math.fabs(ys[j + i]))

        zs = np.array(frame)
        rms2 = (np.sqrt(int(np.mean(zs ** 2))))
        vals.append(rms2)
        #print('noise level: ', noise_level)
        if (num_block > 10) and (start_point == 0):      # szansa na oznaczenie startu
            #print("valx block: ", num_block, "  ", vals[num_block])
            if (vals[num_block] > noise_level)and (vals[num_block - 2] > noise_level) and (vals[num_block - 4] > noise_level):
                #print("jest!!!!")
                start_point = (num_block - 4) * block
                #return start_point
        elif(start_point != 0):    # end point setting
            small_list = vals[num_block-5:num_block]
            if (mean(small_list) <= noise_level):#(vals[num_block - 5] < noise_level)and(vals[num_block - 4] < noise_level)and(vals[num_block - 3] < noise_level)and(vals[num_block - 2] < noise_level)and(vals[num_block - 1] < noise_level):
                #print("rozmiar ciszy: ", len(small_list))
                end_point = num_block * block
        if(start_point != 0) and (end_point != 0):
            print('punkty: ', start_point, "    ", end_point)
            return [start_point, end_point];
        j += block
        num_block += 1
        frame.clear()
    return [-1, -1];

# Gotowa:
def threshold(arr, block):
    """
    Function gives us level of threshold counted from
    first 0.5s of file, which is probably only noise...
    :param ys:  numpy array of file fragment
    :param block:   number of frames
    :return:
    """
    max_block = int(len(arr) / block)
    num_block = 0
    frame = []
    min_max = []
    j = 0
    while (num_block < max_block):
        for i in range(0, block):
            frame.append(math.fabs(arr[j + i]))

        j += block
        zs = np.array(frame)
        rms = (np.sqrt(int(np.mean(zs ** 2))))
        min_max.append(rms)

        num_block += 1
        frame.clear()

    threshold = int(max(min_max) + 1)
    min_max.clear()
    return threshold

# Gotowa:
def get_words(word_path):
    with open(word_path) as f:
        flat_list = [word for line in f for word in line.split()]
    return flat_list

def cut_on_start(rec_folder):
    file_list = os.listdir(rec_folder)

def noise_recording(path, rec_folder):
    time.sleep(1)
    p = pyaudio.PyAudio()  # Create an interface to PortAudio
    noise_filename = "noise" + ".wav"
    noise_full_path = os.path.join(path, rec_folder, noise_filename)
    stream = p.open(format=sample_format,
                    channels=channels,
                    rate=fs,
                    frames_per_buffer=chunk,
                    input=True)

    tmp_noise = []  # Array to store sample of ambient noise

    for i in range(0, int(fs / chunk * 0.5)):
        noise_data = stream.read(chunk, exception_on_overflow=False)
        tmp_noise.append(noise_data)

    # Stop and close the stream
    stream.stop_stream()
    stream.close()
    print(len(tmp_noise))
    # Save the recorded noise as a WAV file
    wf = wave.open(noise_full_path, 'wb')
    wf.setnchannels(channels)
    wf.setsampwidth(p.get_sample_size(sample_format))
    wf.setframerate(fs)
    wf.writeframes(b''.join(tmp_noise))
    wf.close()
    p.terminate()
    tmp_noise.clear()

def words_sample_recording(full_path):
    p = pyaudio.PyAudio()  # Create an interface to PortAudio
    stream = p.open(format=sample_format,
                    channels=channels,
                    rate=fs,
                    frames_per_buffer=chunk,
                    input=True)

    frames = []  # Initialize array to store frames
    for i in range(0, int(fs / chunk * seconds)):
        data = stream.read(chunk, exception_on_overflow=False)
        frames.append(data)

    stream.stop_stream()
    stream.close()
    wf = wave.open(full_path, 'wb')
    wf.setnchannels(channels)
    wf.setsampwidth(p.get_sample_size(sample_format))
    wf.setframerate(fs)
    wf.writeframes(b''.join(frames))
    wf.close()
    # Terminate the PortAudio interface
    p.terminate()
    frames.clear()


def main():
    """
    function for recording samples of spoken words, according to the list.txt file
    :return:
    """
    path = os.getcwd()                                  # Deklaracja ścieżki do plików:
    rec_folder = "voice_samples"
    name = input("Podaj imię osoby nagrywanej: ")
    base_filename = str("_" + name)
    word_file = "lista.txt"
    folder_path = os.path.join(path, rec_folder)

    try:                                                # tworzenie folderu do przechowywania nagrań:
        if os.path.exists(folder_path) == 0:
            os.mkdir(folder_path, 0o755)
    except:
        print(" Error - "
              "can't create folder - ")

    noise_recording(path, rec_folder)                   # Ngrywanie próbki szumu zastanego:
    word_path = os.path.join(path, word_file)           # Odczytanie pliku ze słowami do nagrania:
    word_list = get_words(word_path)                    # stworzenie listy słów do nagrania:

    for nazwa in word_list:
        filename = nazwa + base_filename + ".wav"
        full_path = os.path.join(folder_path, filename)
        print("wciśnij ENTER")
        print("i powiedz: ", nazwa)
        input()
        print('Recording')
        time.sleep(0.2)
        words_sample_recording(full_path)

    print('Finished recording')

if __name__ == '__main__':
    main()

exit()

